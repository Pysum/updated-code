import csv


def authenticate_user(ntid, password):
    with open('user_data.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if len(row) >= 6:  # Make sure the row has at least 5 elements
                stored_ntid = row[1].lower()  # Convert stored_ntid to lowercase
                stored_password = row[4]
                if ntid.lower() == stored_ntid and password == stored_password:
                    role = row[0]
                    return role  # Return the role if the authentication is successful
    return None  # Return None if the authentication fails


# Test the authenticate_user function with user input
# user_ntid = input("Enter NTID: ")
# user_password = input("Enter Password: ")

# user_role = authenticate_user(user_ntid, user_password)

# if user_role is None:
#     print("Authentication failed. Invalid NTID or password.")
# else:
#     print("Authentication successful. User role:", user_role)

def get_user_name(ntid):
    with open('user_data.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if len(row) >= 5:  # Make sure the row has at least 5 elements
                stored_ntid = row[1].lower() 
                if ntid.lower() == stored_ntid:
                    name = row[2]  # Assuming the user name is in the third column
                    return name  # Return the user name
    return None  

