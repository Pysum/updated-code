from flask import Flask, render_template, redirect, url_for, request,jsonify,send_from_directory

from submit_signup import create_account
from submit_signin import sign_in
from password_change import change_password
from ticket_generator import generate_ticket
from quality_random_feedID import generate_quality_ticket
from get_date import get_formatted_date
from search_csv import search_csv_file
from save_feedback_form import save_feedback_data
from fetch_feedback_data import feedbackData_csv
from acknowledge_feedback import acknowledge
from display_unacfeedback import fetch_unacfeedback
from fetch_FReport_database import fetch_FReport_aor_data, fetch_FReport_team_leaders,fetch_FReport_employee_data
from fetch_FeedForm_database import fetch_FeedForm_aor_data,fetch_FeedForm_team_leaders,fetch_FeedForm_employee_data
from fetch_unAcknowledged_feedback import unack_feedbackData_csv
# from quality_feedback_score_calculate import calculate_total_score
from pull_feedback_report import fetch_feedback_report
from export_feedbackReport import receive_feedback_report






app = Flask(__name__, static_folder='static')
app.config['ATSC_TEAMS_FOLDER'] = 'ATSC_Teams'  
app.config['ATSC_FEEDBACK_FOLDER'] = 'ATSC_Feedback'  
app.config['ACKNOWLEDGED_FEEDBACK_FOLDER'] = 'acknowledged_feedback'

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/signup.html')
def sign_up():
    return render_template('signup.html')

@app.route('/submit_signup', methods=['POST'])
def create_account_route():
    return create_account()


@app.route('/submit_signin', methods=['POST'])
def sign_in_route():
    return sign_in()
  
@app.route('/change-pass', methods=['POST'])
def change_password_route():
    return change_password()


@app.route('/cpwd_success.html')
def cpwd_success():
    return render_template('cpwd_success.html')

@app.route('/favicon.ico')
def favicon():
    return app.send_static_file('favicon.ico')

@app.route('/login.html')
def login():
    return render_template('login.html')

@app.route('/cpwd.html')
def cpwd():
    return render_template('cpwd.html')

@app.route('/agent.html')
def agent_page():
    return render_template('agent.html')

@app.route('/teamlead.html')
def team_lead_page():
    return render_template('teamlead.html')

@app.route('/error_code.html')
def error_code():
    return render_template('error_code.html')

@app.route('/existing_user.html')
def existing_user():
    return render_template('existing_user.html')

@app.route('/signup_success.html')
def signup_success():
    return render_template('signup_success.html')

@app.route('/display_unacfeedback.html')
def unack_feedback():
    
    return render_template('display_unacfeedback.html')

@app.route('/display_acfeedback.html')
def ack_feedback():
    
    return render_template('display_acfeedback.html')


@app.route('/fetch_all_feedback', methods=['GET'])
def fetch_feedback():
    name = request.args.get('name')
    feedback_id = request.args.get('feedbackId')
    return fetch_unacfeedback(name=name,feedback_id=feedback_id)
    

@app.route('/feedback_form.html')
def feedback_form():
    name = request.args.get('name')  # Retrieve the name from the query parameter
    ticket_id = generate_ticket()
    current_date = get_formatted_date()
    return render_template('feedback_form.html', name=name,ticket_id = ticket_id,date=current_date)

@app.route('/feedback_report.html')
def feedback_report():
    name = request.args.get('name')  # Retrieve the name from the query parameter
    return render_template('feedback_report.html', name=name)

@app.route('/create_scorecard.html')
def create_scorecard():
    name = request.args.get('name')  # Retrieve the name from the query parameter
    current_date = get_formatted_date()
    return render_template('create_scorecard.html', date = current_date,name=name)

@app.route('/quality_feedback_form.html')
def quality_feedback_form():
    name = request.args.get('name')  # Retrieve the name from the query parameter
    current_date = get_formatted_date()
    return render_template('quality_feedback_form.html', name=name,date=current_date)


  

@app.route('/search_csv')
def search_csv():
    return search_csv_file()


@app.route("/save-feedback", methods=["POST"])
def save_feedback():
    return save_feedback_data()


@app.route('/all_feedbackData_csv')
def feedbackDataRoute():
    return feedbackData_csv()

@app.route('/unack_feedbackData_csv')
def unack_feedbackDataRoute():
    return unack_feedbackData_csv()



@app.route('/acknowledge', methods=['POST'])
def acknowledge_feedback():
    if request.is_json:
        json_data = request.get_json()
        return acknowledge(json_data=json_data)
    

# Define the route for receiving feedback search data
@app.route('/feedback_report', methods=['POST'])
def pull_feedback_report():
    data = request.json

    month = int(data['month'])
    year = int(data['year'])
    employee_names = data['employeeName']
    
    return fetch_feedback_report(month, year, employee_names)
   


        

@app.route('/evaluate', methods=['POST'])
def evaluate():
    data = request.get_json()
    selected_count = data.get('selectedCount', 0)
    total_score = selected_count  # Correct scoring logic (Yes/NA=5, No=0 for each question)
    print(data)

    return jsonify({'totalScore': total_score})

############ Feedback form page user data#####################
@app.route('/fetch_FeedForm_aor_data')
def display_FeedForm_aor ():
    return fetch_FeedForm_aor_data()

@app.route('/fetch_FeedForm_team_leaders')
def display_FeedForm_manager():
    return fetch_FeedForm_team_leaders()

@app.route('/fetch_FeedForm_employee_data')
def display_FeedForm_agents():
    return fetch_FeedForm_employee_data()

############ Feedback report page user data#####################
@app.route('/fetch_FReport_aor_data')
def display_FReport_aor ():
    return fetch_FReport_aor_data()

@app.route('/fetch_FReport_team_leaders')
def display_FReport_manager():
    return fetch_FReport_team_leaders()

@app.route('/fetch_FReport_employee_data')
def display_FReport_agents():
    return fetch_FReport_employee_data()


@app.route('/export-feedbackReport', methods=['POST'])
def handle_feedback_report():
    data = request.json
    result = receive_feedback_report(data)
    return result



if __name__ == '__main__':
    app.run(debug=True)


















