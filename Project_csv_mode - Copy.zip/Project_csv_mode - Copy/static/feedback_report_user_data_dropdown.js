document.addEventListener("DOMContentLoaded", function () {
  const aorDropdownLabel = document.getElementById("aor-dropdown-label");
  const aorDropdownList = document.getElementById("aor-dropdown");

  // Function to toggle the visibility of the AOR dropdown list
  function toggleAORDropdown() {
    aorDropdownList.classList.toggle("show");
  }

  // Function to hide the AOR dropdown list
  function hideAORDropdown() {
    aorDropdownList.classList.remove("show");
  }

  // Add click event listener to the AOR label
  aorDropdownLabel.addEventListener("click", toggleAORDropdown);

  // Add a click event listener on the document to hide the AOR dropdown when anywhere on the screen is clicked
  document.addEventListener("click", function (event) {
    if (event.target !== aorDropdownLabel && !aorDropdownList.contains(event.target)) {
      hideAORDropdown();
    }
  });

  // Function to populate the AOR checkboxes
  function fetchAORData() {
    // Replace the URL with your actual endpoint that fetches AOR data
    fetch('/fetch_FReport_aor_data')
      .then(function(response) {
        return response.json();
      })
      .then(function(aorData) {
        // Clear the existing content in the AOR dropdown
        aorDropdownList.innerHTML = '';

        // Create "Select All" checkbox
        const selectAllCheckbox = document.createElement("input");
        selectAllCheckbox.type = "checkbox";
        selectAllCheckbox.name = "select-all-checkbox";
        selectAllCheckbox.id = "select-all-checkbox";
        selectAllCheckbox.value = "select-all";

        const selectAllLabel = document.createElement("label");
        selectAllLabel.textContent = "Select All";
        selectAllLabel.insertBefore(selectAllCheckbox, selectAllLabel.firstChild);


        // Create checkboxes for each AOR
        aorData.forEach(function(aor) {
          const label = document.createElement("label");
          label.className = "aor-checkbox-label";

          const checkbox = document.createElement("input");
          checkbox.type = "checkbox";
          checkbox.name = "aor-checkbox";
          checkbox.value = aor;

          label.appendChild(checkbox);
          label.appendChild(document.createTextNode(aor));

          // Append the AOR label and checkbox to the dropdown
          aorDropdownList.appendChild(label);
        });

        // Append the "Select All" checkbox at the beginning
        aorDropdownList.insertBefore(selectAllLabel, aorDropdownList.firstChild);
        // Add event listener to "Select All" checkbox
      const aorCheckboxes = document.querySelectorAll("input[name=aor-checkbox]");
      const teamLeaderDropdown = document.getElementById('team-leader-dropdown');
    
      // Create a dictionary to store selected AORs and their corresponding team leaders
      const selectedAORs = {};

      // Add event listener to individual AOR checkboxes
      aorCheckboxes.forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
          if (checkbox.checked) {
            fetchTeamLeaders(checkbox.value, teamLeaderDropdown, selectedAORs);
          } else {
            delete selectedAORs[checkbox.value];
            updateTeamLeadersUI(selectedAORs, teamLeaderDropdown);
          }
        });
      });
      // Add event listener to "Select All" AOR checkbox
// Add event listener to "Select All" AOR checkbox
selectAllCheckbox.addEventListener("change", function () {
  const aorCheckboxes = document.querySelectorAll("input[name=aor-checkbox]");
  const isChecked = selectAllCheckbox.checked;

  aorCheckboxes.forEach(function (checkbox) {
    checkbox.checked = isChecked;

    if (isChecked) {
      selectedAORs[checkbox.value] = true;
      fetchTeamLeaders(checkbox.value, teamLeaderDropdown, selectedAORs);
    } else {
      delete selectedAORs[checkbox.value];
    }
  });

  updateTeamLeadersUI(selectedAORs, teamLeaderDropdown);
});


      })
      .catch(function(error) {
        console.log('Error fetching AOR data:', error);
      });
  }

  

  // Call the fetchAORData function to populate AOR checkboxes on page load
  fetchAORData();
});




function fetchTeamLeaders(selectedAOR, teamLeaderDropdown, selectedAORs) {
  // Send a request to the server to fetch team leaders data for the selected AOR
  fetch('/fetch_FReport_team_leaders?selectedAOR=' + encodeURIComponent(selectedAOR))
    .then(response => response.json())
    .then(data => {
      selectedAORs[selectedAOR] = data;
      updateTeamLeadersUI(selectedAORs, teamLeaderDropdown);


    })
    .catch(error => {
      console.error('Error fetching team leaders:', error);
    });
}

function updateTeamLeadersUI(selectedAORs) {
  const teamLeaderDropdown = document.getElementById("team-leader-dropdown");
  teamLeaderDropdown.innerHTML = ''; // Clear team leader dropdown

  const allTeamLeaders = Object.values(selectedAORs).flat();

  if (allTeamLeaders.length === 0) {
    teamLeaderDropdown.classList.remove("show"); // Hide the dropdown
    return;
  }

  // Create "Select All" checkbox
  const selectAllCheckbox = document.createElement("input");
  selectAllCheckbox.type = "checkbox";
  selectAllCheckbox.name = "select-all-team-leaders";
  selectAllCheckbox.id = "select-all-team-leaders";
  selectAllCheckbox.value = "select-all";

  const selectAllLabel = document.createElement("label");
  selectAllLabel.textContent = "Select All";
  selectAllLabel.insertBefore(selectAllCheckbox, selectAllLabel.firstChild);

  // Create checkboxes for each team leader
  allTeamLeaders.forEach(teamLeader => {
    const label = document.createElement("label");
    label.className = "team-leader-checkbox-label";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "team-leader-checkbox";
    checkbox.value = teamLeader;

    label.appendChild(checkbox);
    label.appendChild(document.createTextNode(teamLeader));

    // Append the team leader label and checkbox to the dropdown
    teamLeaderDropdown.appendChild(label);
  });

 


  // Append the "Select All" checkbox at the beginning
  teamLeaderDropdown.insertBefore(selectAllLabel, teamLeaderDropdown.firstChild);

  selectAllCheckbox.addEventListener("change", function () {
    const checkboxes = document.querySelectorAll("input[name=team-leader-checkbox]");
    checkboxes.forEach(function (checkbox) {
      checkbox.checked = selectAllCheckbox.checked;
      checkbox.dispatchEvent(new Event("change")); // Trigger change event for individual checkboxes
    });
  });
  
  // Add event listener to individual team leader checkboxes
  const teamLeaderCheckboxes = document.querySelectorAll("input[name=team-leader-checkbox]");
  
  teamLeaderCheckboxes.forEach(function (checkbox) {
    checkbox.addEventListener("change", function () {
      updateEmployeeDataUI(selectedAORs);
    });
  
  

    // Update employee data UI based on selected team leaders
    updateEmployeeDataUI(selectedAORs);
  });

  teamLeaderDropdown.classList.add("show"); // Show the dropdown
}
// Add event listener to toggle the team leader dropdown
// Add event listener to toggle the team leader dropdown
const teamLeaderToggle = document.getElementById("team-leader-toggle");
const teamLeaderDropdown = document.getElementById("team-leader-dropdown");

teamLeaderToggle.addEventListener("click", function (event) {
  event.stopPropagation(); // Prevent the click from propagating to the document
  teamLeaderDropdown.classList.toggle("show");
});

// Add event listener to hide the dropdown when clicking anywhere else on the screen
document.addEventListener("click", function (event) {
  if (teamLeaderDropdown.classList.contains("show")) {
    if (!teamLeaderDropdown.contains(event.target)) {
      teamLeaderDropdown.classList.remove("show");
    }
  }
});

// Add event listener to prevent dropdown from closing when clicking inside the dropdown
teamLeaderDropdown.addEventListener("click", function (event) {
  event.stopPropagation(); // Prevent the click from propagating to the document
});






// Rest of your code...





// Function to fetch employee names based on the selected team leader
function fetchEmployeeData(selectedTeamLeaders) {
  // Send a request to the server to fetch employee data
  fetch('/fetch_FReport_employee_data?selectedTeamLeaders=' + encodeURIComponent(selectedTeamLeaders))
    .then(function (response) {
      return response.json();
    })
    .then(function (employeeData) {
      const employeeDropdown = document.getElementById("employee-dropdown");
      employeeDropdown.innerHTML = ''; // Clear previous checkboxes

      // Create "Select All" checkbox for employees
      const selectAllEmployeeCheckbox = document.createElement("input");
      selectAllEmployeeCheckbox.type = "checkbox";
      selectAllEmployeeCheckbox.name = "select-all";
      selectAllEmployeeCheckbox.id = "select-all";
      selectAllEmployeeCheckbox.value = "select-all";

      const selectAllEmployeeLabel = document.createElement("label");
      selectAllEmployeeLabel.textContent = "Select All";
      selectAllEmployeeLabel.insertBefore(selectAllEmployeeCheckbox, selectAllEmployeeLabel.firstChild);

      // Append the "Select All" checkbox for employees at the beginning
      employeeDropdown.appendChild(selectAllEmployeeLabel);

      // Create checkboxes for each employee
      employeeData.forEach(function (employee) {
        const label = document.createElement("label");
        label.className = "employee-checkbox-label";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.name = "employee-checkbox";
        checkbox.value = employee;

        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(employee));

        // Append the employee label and checkbox to the dropdown
        employeeDropdown.appendChild(label);
      });

      // Add event listener to "Select All" checkbox
      selectAllEmployeeCheckbox.addEventListener("change", function () {
        const employeeCheckboxes = document.querySelectorAll("input[name=employee-checkbox]");
        employeeCheckboxes.forEach(function (checkbox) {
          checkbox.checked = selectAllEmployeeCheckbox.checked;
        });
      

      });
    })
    .catch(function (error) {
      console.log('Error fetching employee data:', error);
    });

}


function updateEmployeeDataUI(selectedAORs) {
  const selectedTeamLeaders = [];
  const teamLeaderCheckboxes = document.querySelectorAll("input[name=team-leader-checkbox]");

  // Get the selected team leaders
  teamLeaderCheckboxes.forEach(function (checkbox) {
    if (checkbox.checked) {
      selectedTeamLeaders.push(checkbox.value);
    }
  });

  // Display employee data based on selected team leaders
  if (selectedTeamLeaders.length > 0) {
    // Fetch and populate employee data for the selected team leaders
    fetchEmployeeData(selectedTeamLeaders.join(',')); // Pass comma-separated list
  } else {
    clearEmployeeDataUI();
  }
  
}




function clearEmployeeDataUI() {
  const employeeDropdown = document.getElementById("employee-dropdown");
  employeeDropdown.innerHTML = ''; // Clear employee data UI
}

// Get a reference to the employee dropdown and its label
const employeeToggle = document.getElementById("employee-toggle");
const employeeDropdownList = document.querySelector(".employee-dropdown-list");

// Add a global click event listener to hide the dropdown when clicking outside of it
document.addEventListener("click", function (event) {
  if (!employeeDropdownList.contains(event.target) && event.target !== employeeToggle) {
    employeeDropdownList.classList.remove("show");
  }
});

// Add a click event listener to the label
employeeToggle.addEventListener("click", function () {
  // Toggle the 'show' class on the dropdown list to show/hide it
  employeeDropdownList.classList.toggle("show");
});



// Prevent click propagation within the employee dropdown
employeeDropdownList.addEventListener("click", function (e) {
  e.stopPropagation();
});



