function resetForm() {
    location.reload();
  }